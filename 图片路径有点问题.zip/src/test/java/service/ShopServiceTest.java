package service;

import static org.junit.Assert.assertEquals;

import java.util.Date;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import basetest.BaseTest;
import dto.ShopExecution;
import entity.Area;
import entity.Shop;
import entity.ShopCategory;

public class ShopServiceTest extends BaseTest{
	
	@Autowired
	private ShopService shopService;
	
	@Test
	public void testAddShop()  {
		Shop shop = new Shop();
 		shop.setOwnerId(1L);
 		//Area area = new Area();
 		
 		shop.setShopName("mytest1");
 		shop.setShopDesc("mytest1");
 		shop.setShopAddr("testaddr1");
 		shop.setPhone("13810524526");
 		shop.setShopImg("test1");
 		shop.setLongitude(1D);
 		shop.setLatitude(1D);
 		shop.setCreateTime(new Date());
 		shop.setLastEditTime(new Date());
 		shop.setEnableStatus(0);
 		shop.setAdvice("审核中");
 		//shop.setArea(area);
 		//shop.setShopCategory(sc);
 		//ShopExecution se = shopService.addShop(shop);
 		//assertEquals(22, se.getShop().getShopName());
 	}
//	
//	
///	@Test
//	public void testAddShop2()  {
//		Shop shop = new Shop();
//		shop.setOwnerId(1L);
//		
//		shop.setShopName("mytest2");
//		shop.setShopDesc("mytest2");
//		shop.setShopAddr("testaddr1");
//		shop.setPhone("13810524526");
//		
//		shop.setLongitude(1D);
//		shop.setLatitude(1D);
//		shop.setCreateTime(new Date());
//		shop.setLastEditTime(new Date());
//		shop.setEnableStatus(0);
//		shop.setAdvice("审核中");
//		
//		
//		int x = shopService.addShop2(shop);
//		assertEquals(22, x);
//	}

}
