package dao;

import java.util.List;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import basetest.BaseTest;
import entity.Order;
import entity.User;

public class OrderDaoTest extends BaseTest{
	
	@Autowired
	private OrderDao orderDao;
	
	@Test
	public void testQueryOrder() {
		User user = new User();
		user.setId(3);
		
		Order order = new Order();
		order.setUser(user);
		
		List<Order> list = orderDao.queryOrderList(order, 0, 100);
		System.out.println(list.size());
		
	}

}
