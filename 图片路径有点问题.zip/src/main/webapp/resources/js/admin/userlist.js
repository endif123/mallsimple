/**
 * 
 */

 $(function(){
	 
	 alert("欢迎登录");
	 getlist();
	 
	 function getlist(e) {
			$.ajax({
				url : "/mall/user/list",
				type : "get",
				dataType : "json",
				success : function(data) {
					if (data.success) {
						handleList(data.userList);
						//handleUser(data.user);
					}
				}
			});
	}
	 
	 function handleList(data) {
			var html = '';
			data.map(function (item, index) {
				html += '<div class="row row-shop"><div class="col-20">'
					+ item.id +'</div><div class="col-20">'
					+ item.name +'</div><div class="col-20">'
					+ item.type +'</div><div class="col-20">' 
					+ item.cost +'</div><div class="col-20">'
					+ goUser(item.id) + deleteUser(item.id) +'</div></div>';

			});
			$('.shop-wrap').html(html);
		}
	 
	 function goUser(id) {
			
				return '<a href="/mall/user/getuserpage?userId='+ id +'" external>进入</a>';
			
		}
	 
	 function deleteUser(id) {
			
			return '<a href="/mall/user/deleteuserbyid?userId='+ id +'" external>删除</a>';
		
	}
	 
	 
	 $.init();
	 
 });