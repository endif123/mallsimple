package service;

import java.util.List;

import entity.Area;

public interface AreaService {
	List<Area> getAreaList();
}
