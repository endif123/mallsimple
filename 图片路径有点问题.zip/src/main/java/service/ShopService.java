package service;

import java.io.File;

import dto.ShopExecution;
import entity.Shop;

public interface ShopService {
	
	ShopExecution addShop(Shop shop, File shopImg);
	
	int addShop2(Shop shop);

}
