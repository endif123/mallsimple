package service;

import java.io.File;
import java.io.InputStream;
import java.util.List;

import org.springframework.web.multipart.commons.CommonsMultipartFile;

import dto.ImageHolder;
import dto.ProductExecution;
import entity.Product;

public interface ProductService {
	
	/**
	 * 
	 * 取出所有的产品
	 * @param productId
	 * @return
	 */
	List<Product> selectAllProduct() throws RuntimeException;

	
	/**
	 * 
	 * 通过id查产品
	 * @param productId
	 * @return
	 */
	Product selectByPrimaryKey(Integer productId) throws RuntimeException;

	/**
	 * 
	 * @param productCondition   必须是对象才行
	 * @param pageIndex  第几页？
	 * @param pageSize    一页多少个
	 * @return
	 */
	 
	ProductExecution getProductList(Product productCondition, int pageIndex, int pageSize);
	
	/**
	 * 更新产品信息
	 */
	ProductExecution updateProduct(Product product, ImageHolder thumbnail) throws RuntimeException;

	
	/**
	 * 删除某个id的产品
	 */
	int deleteByPrimaryKey(Integer productId) throws RuntimeException;
	
	/**
	 * 添加某个产品
	 */
	ProductExecution addProduct(Product product, ImageHolder thumbnail) throws RuntimeException;

}
