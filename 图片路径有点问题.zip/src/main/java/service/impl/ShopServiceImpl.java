package service.impl;

import java.io.File;
import java.util.Date;

import javax.management.RuntimeErrorException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import dao.ShopDao;
import dto.ShopExecution;
import entity.Shop;
import enums.ShopStateEnum;
import service.ShopService;
import util.ImageUtil;
import util.PathUtil;
@Service
public class ShopServiceImpl implements ShopService {
	
	@Autowired
	private ShopDao shopDao;

	@Override
	@Transactional
	public ShopExecution addShop(Shop shop, File shopImg) {
		//空值判断
		if(shop == null ) {
			return new ShopExecution(ShopStateEnum.NULL_SHOPID);
		}
		try {
			//给店铺信息赋值初始值
			shop.setEnableStatus(0);
			shop.setCreateTime(new Date());
			shop.setLastEditTime(new Date());
			//添加店铺信息
			int effectedNum = shopDao.insertShop(shop);
			
			if(effectedNum <= 0) {
				throw new RuntimeException("店铺创建失败");
			}else {
				if(shopImg != null) {
					//储存图片
					try {
					//addShopImg(shop,shopImg);
				}catch(Exception e) {
					throw new RuntimeException("存储图片失败"+e.getMessage());
					}
					//更新店铺的图片地址
					//effectedNum = shopDao.updateShop(shop);
				}
			}
		}catch(Exception e) {
			throw new RuntimeException(e.getMessage());
		}
		return new ShopExecution(ShopStateEnum.CHECK, shop);
	}
	
	
//	private void addShopImg(Shop shop, File shopImg) {
//		//获取shop图片的相对值路径
//		String dest = PathUtil.getProductImagePath(shop.getShopId());
//		//String shopImgAddr = ImageUtil.generateThumbnail(shopImg, dest);
//		//shop.setShopImg(shopImgAddr);
//	}

	@Override
	public int addShop2(Shop shop) {
		// TODO Auto-generated method stub
		return shopDao.insertShop(shop);
	}

	
}
