package web.user;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.fasterxml.jackson.databind.ObjectMapper;

import entity.User;
import service.LoginService;
import util.CodeUtil;
import util.HttpServletRequestUtil;

@Controller
@RequestMapping("/login")
public class LoginController {
	
	@Autowired
	private LoginService loginService;
	
	/**
	 * 路由，登录
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/userlogin", method = RequestMethod.GET)
	private String addProductTest(HttpServletRequest request){
		
		return "login/login";
	}
	
	/**
	 * 会验证传过来的用户密码，返回如果正确返回user
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/loginsubmit")
	@ResponseBody
	private Map<String,Object> loginsubmit(HttpServletRequest request){
		Map<String, Object> modelMap = new HashMap<String, Object>();
		//验证码验证
		if (!CodeUtil.checkVerifyCode(request)) {
			modelMap.put("success", false);
			modelMap.put("errMsg", "输入了错误的验证码");
			return modelMap;
		}
		
		//-------获得对象
		
		//首先拿到字符串，有个检验过程
		String userStr = HttpServletRequestUtil.getString(request, "userStr");
		//反射走起
		ObjectMapper mapper = new ObjectMapper();
		User user = null;
		try {
			user = mapper.readValue(userStr, User.class);
		}catch(Exception e) {
			modelMap.put("success", false);
			modelMap.put("errMsg", e.getMessage());
		}
		//验证用户是否正确
		User userFlag = loginService.CheckUserPassword(user);
		if(userFlag == null) {
			modelMap.put("success", false);
			modelMap.put("errMsg", "用户名或密码错误");
			return modelMap;
		}
		//如果正确，写入session
		userFlag.setPassword(null);
		request.getSession().setAttribute("user",userFlag);
		
		//request.getParameter("userStr");
		modelMap.put("success", true);
		modelMap.put("user", userFlag);
		return modelMap;
	}

}
