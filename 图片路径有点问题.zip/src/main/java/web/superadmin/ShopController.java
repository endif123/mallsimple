package web.superadmin;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import entity.Shop;
import util.HttpServletRequestUtil;

@Controller
@RequestMapping("/shop")
public class ShopController {
	
	
	@RequestMapping(value = "/registershop", method = RequestMethod.POST)
	@ResponseBody
	private Map<String, Object> registerShop(HttpServletRequest request){
		//1. 接收并转化相应的参数
		//2. 注册店铺
		//3. 返回结果
		Map<String, Object> modelMap = new HashMap<String, Object>();
		//1. 接收并转化相应的参数
		HttpServletRequestUtil.getString(request, "shopStr");
		Shop shop = null;
		return null;
		
	}

}
