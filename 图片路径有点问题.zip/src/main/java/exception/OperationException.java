package exception;

public class OperationException extends RuntimeException{
	/**
	 * 
	 */
	private static final long serialVersionUID = 8697781594233269003L;

	public OperationException(String msg) {
		super(msg);
	}

}
