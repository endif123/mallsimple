package dao;

import java.util.List;

import entity.Area;

public interface AreaDao {
	/**
	 * 列出区域列表
	 * @return list
	 */
	List<Area> queryArea();
}
