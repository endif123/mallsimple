package dao;

import java.util.List;

import entity.Category;
import entity.User;

public interface CategoryDao {
	
	Category selectByPrimaryKey(Integer categoryId);
	
	//查询所有的类别
	List<Category> selectAllCategory();

}
